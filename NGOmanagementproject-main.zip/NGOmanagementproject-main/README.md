# NGOmanagementproject
first repository
